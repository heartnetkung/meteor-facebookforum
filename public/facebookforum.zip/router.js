Posts = new Meteor.Collection('posts');

Router.configure({
	data : function() {
		return {
			params : _.clone(this.params)
		};
	}
});

Router.map(function() {
	this.route('home', {
		path : '/'
	});

	this.route('postpage', {
		path : 'post/:_id',
		data : function() {
			return {
				'post_id' : this.params._id
			};
		}
	});
});
